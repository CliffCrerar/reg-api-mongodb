const 
    path = require('path');
    app = require(path.join(__dirname, 'app.js'));
exports.authUserApi = app;